package com.crm.qa.util;

import com.crm.qa.base.TestBase;

public class Testutil extends TestBase{
	public static long PAGE_LOAD_TIMEOUT=30;
	public static long IMPLICITWAIT_WAIT=10;

	public void  switchtoframe() {
		driver.switchTo().frame("mainpanel");

	}


}
